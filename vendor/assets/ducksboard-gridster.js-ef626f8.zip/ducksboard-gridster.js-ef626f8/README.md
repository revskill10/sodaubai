Gridster.js
===========

Gridster is a jQuery plugin that makes building intuitive draggable
layouts from elements spanning multiple columns. You can even
dynamically add and remove elements from the grid.

More at [http://gridster.net/](http://gridster.net/).

Updating Begins
===============

Hi all, I have begun merging my fork with the main repository
and am making some much needed fixes in the process.

I am devoting an hour a day until it gets done.

Thanks,

Dustin


Public Service Announcement from Dustin Moore (dustmoo)
=======================================================

Gridster is not currently being actively maintained by 
[Ducksboard](http://ducksboard.com/).

I and others have been given access to the repo to help
 maintain and address issues.

I have created a fork of gridster that supports more advanced
 features, like widget-swapping and static widgets.

It can be found here: https://github.com/dustmoo/gridster.js

Currently the code-base is different and I don't have time to
reconcile the fork with this repo. 

If anyone would like to help me improve my fork and reconcile 
it with the main library I would be happy for the help.


License
=======

Distributed under the MIT license.

Whodunit
========

Gridster is built by [Ducksboard](http://ducksboard.com/).
